# Downloads the MSIX signed by Microsoft
# This is useful to publish the MSIX outside of the store
# Original script can be found in https://github.com/MattiasC85/Scripts/blob/master/OSD/Download-AppxFromStore.ps1
.\scripts\msix\msix_downloader.ps1 -StoreURL https://www.microsoft.com/store/productId/9NCB4Z0TZ6RR
