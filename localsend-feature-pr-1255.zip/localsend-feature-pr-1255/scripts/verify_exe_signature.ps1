$signtoolPath = "C:\Program Files (x86)\Windows Kits\10\bin\10.0.19041.0\x64\signtool.exe"
& $signtoolPath verify build\windows\runner\Release\localsend_app.exe