import share_handler_ios_models
    
class ShareViewController: ShareHandlerIosViewController {}
