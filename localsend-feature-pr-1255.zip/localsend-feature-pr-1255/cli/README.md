# cli

The LocalSend CLI.
